var __wpo = {
  "assets": {
    "main": [
      "/7d316b6786c13e4fc8bb0f67f1c96f4b.ttf",
      "/6f8391bbdaeaa540388796c858dfd8ca.ttf",
      "/d45bdbc2d4a98c1ecb17821a1dbbd3a4.ttf",
      "/8946a97f50e94a7deeb904d07c037d84.svg",
      "/fdc86acae5a89310fc380101d4dd28ef.svg",
      "/af9dedec7b7c5b4e0249433170abd50b.ttf",
      "/043112d9986804e8f6fbb0b9924ee8be.ttf",
      "/6fa3da851e142b514ac7f0e125955e4c.ttf",
      "/fcc40ae9a542d001971e53eaed948410.ttf",
      "/8d586f0d57175932fda77b7428f359de.jpg",
      "/4b3f06816033d040ef0ed60865adb2d1.ttf",
      "/bad01a8965b8562e2e7447fe04723acd.woff",
      "/01555d25092b213d2ea3a982123722c9.ttf",
      "/cf5ba39d9ac24652e25df8c291121506.ttf",
      "/6fe3b5a279da558e38cdcbe86f91430b.svg",
      "/b868bb17c2c69b4cbeb6a079b28df21a.svg",
      "/9ec263601ee3fcd71763941207c9ad0d.ttf",
      "/6f1520d107205975713ba09df778f93f.ttf",
      "/robots.txt",
      "/d9a3bda6cacc5a776e8e8007c9de86fb.ttf",
      "/f4fc68837a518f012ba1df85e7af3acd.ttf",
      "/5b54162723d1126c98fb68564c60b860.svg",
      "/c1034239929f4651cc17d09ed3a28c69.ttf",
      "/875fbeca9494f6630328545f2708e14b.svg",
      "/f2b064ffc4aa426ea2e2b81bd4662a63.ttf",
      "/17be7aaf2526759a42c66da7683e37d4.svg",
      "/e9c5c588e39d0765d30bcd6594734102.ttf",
      "/76cfeae5ba55025f20b1a633a2aa1810.svg",
      "/77bf2dc2ec18ab13756cbe6aac3e9a45.svg",
      "/6d2534827a098a8753837bdad6dd180a.svg",
      "/43c043bccc84e7e05e2442516ccdd4ff.jpg",
      "/d75199d9299ec99171310c60026a9476.ttf",
      "/favicon.ico",
      "/be57951d47bc6b1635653a38cbdf30fd.woff2",
      "/8afe4dc13b83b66fec0ea671419954cc.ttf",
      "/a840e539f4f9f5b8ceb038072848ae2f.ttf",
      "/14d00dab1f6802e787183ecab5cce85e.ttf",
      "/a9bed017984a258097841902b696a7a6.ttf",
      "/38ff1cb52fae6003a50159bc910b9782.ttf",
      "/fb05c6adb409f27ffe4f9ac4b2a0d323.svg",
      "/9841f3d906521f7479a5ba70612aa8c8.ttf",
      "/08c20a487911694291bd8c5de41315ad.ttf",
      "/19406f767addf00d2ea82cdc9ab104ce.ttf",
      "/fc6854e59e19fbcf27ce8e064054a3ed.svg",
      "/0613c488cf7911af70db821bdd05dfc4.ttf",
      "/093ee89be9ede30383f39a899c485a82.ttf",
      "/11598c28bd4c62d359b58d8a810f385f.ttf",
      "/68c5662ec609e6763f13acc6594809aa.svg",
      "/33bea45d54f9bf1e62b5e9d6b05b6bfe.svg",
      "/890d9910230752c6a88d8b5d5c3a1895.ttf",
      "/699335202b9480f4f7916a8df4fb8f41.jpg",
      "/sitemap.xml",
      "/a511edd89a551e8f0db621724e1f93bd.ttf",
      "/bf59c687bc6d3a70204d3944082c5cc0.ttf",
      "/41520cbd26d45a314080d93e2db791d2.svg",
      "/runtime.8ffac6e7aa9b272269dd.js",
      "/"
    ],
    "additional": [
      "/npm.react-fast-compare.c498ae394b734ed34d88.chunk.js",
      "/npm.react-helmet.27cecc42a65694f42916.chunk.js",
      "/npm.react-side-effect.11d575f686200d838305.chunk.js",
      "/npm.shallowequal.bf436f70b1fcfbf4687e.chunk.js",
      "/npm.intl.322ea77011d5e7e0553b.chunk.js",
      "/main.15c1d803c1116562de6f.chunk.js",
      "/npm.babel.7a100477f9f986a0d18a.chunk.js",
      "/npm.connected-react-router.368edfa3c59066d77d2a.chunk.js",
      "/npm.core-js.7d7d0ec1e85102d35a26.chunk.js",
      "/npm.emotion.3adea6dd86959a260f2c.chunk.js",
      "/npm.mui.c89f6c28a53690bf443b.chunk.js",
      "/npm.react-app-polyfill.28db4f98c175ee200fb7.chunk.js",
      "/npm.react-redux.4ab2238accaf843cb8bb.chunk.js",
      "/npm.react-transition-group.d6427442362ce0cf67df.chunk.js",
      "/npm.redux-saga.b38f02a2426979adfaea.chunk.js",
      "/16.4739e34a03f1322006ef.chunk.js",
      "/17.4f19d52c9f866ac9a832.chunk.js",
      "/18.b8edfdcc92a9abf8b4fc.chunk.js",
      "/19.eec1c0d54ee66cfb38a9.chunk.js",
      "/20.147e4edb3838dafe268a.chunk.js",
      "/21.fb7355dd7478bea7a90b.chunk.js",
      "/22.a0a8ba3cddc024b962be.chunk.js",
      "/23.911ce7216db1baabd93f.chunk.js",
      "/24.f2ad56a9af7537e067c9.chunk.js",
      "/25.b7db9d036b4cd0fb7cfc.chunk.js",
      "/26.d5bb2b95a847f525bda2.chunk.js",
      "/27.638e35060be8481e33e3.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "b4c199c875be86ada0f3580020d092f3ef21703d": "/7d316b6786c13e4fc8bb0f67f1c96f4b.ttf",
    "85af6582a7e6155917c605f9d3fed68c02b23b06": "/6f8391bbdaeaa540388796c858dfd8ca.ttf",
    "4b5c0750f073abd576413a0898d3b95adaf199c8": "/d45bdbc2d4a98c1ecb17821a1dbbd3a4.ttf",
    "acd7f8d4dc9798f1679755dbf0f37a187420392a": "/8946a97f50e94a7deeb904d07c037d84.svg",
    "187083456548059db617f16510866be7ed3f11b7": "/fdc86acae5a89310fc380101d4dd28ef.svg",
    "00e66e2f47133b17ff49d96b251ebb3a2614d713": "/af9dedec7b7c5b4e0249433170abd50b.ttf",
    "73745fef9a577118db0e2f25c4d5c0ac91418ba5": "/043112d9986804e8f6fbb0b9924ee8be.ttf",
    "9dd416bb989087a3e63125f4fea7898c97ff157c": "/6fa3da851e142b514ac7f0e125955e4c.ttf",
    "e247a92158e112f8bf7b638c8d95381d66b00dbb": "/fcc40ae9a542d001971e53eaed948410.ttf",
    "58448412f96c5481650b7cd4b8a551b7fb901024": "/8d586f0d57175932fda77b7428f359de.jpg",
    "d06c7083a79f12a8f70b49fe8901c73b80aeda55": "/4b3f06816033d040ef0ed60865adb2d1.ttf",
    "d9a419a0e36c453d5bca016e11dc3b58fcf4c1c2": "/bad01a8965b8562e2e7447fe04723acd.woff",
    "fb8fccca21550e71135f92bbaf8a2e8a12c90465": "/01555d25092b213d2ea3a982123722c9.ttf",
    "b592c62fdf88c40cfd0f031bba6423b1d4430472": "/cf5ba39d9ac24652e25df8c291121506.ttf",
    "1c3f2bff8e56870f51f68e6b2af4a5448123059d": "/6fe3b5a279da558e38cdcbe86f91430b.svg",
    "1ecde01ca09a29e5a3897a6f4df150e65e0bfc75": "/b868bb17c2c69b4cbeb6a079b28df21a.svg",
    "09ba4dcd5509c8085bf88c665dcc51cbdfced27b": "/9ec263601ee3fcd71763941207c9ad0d.ttf",
    "8a4ace9392d06bcb7f8ea2f5169b07e4c383a90d": "/6f1520d107205975713ba09df778f93f.ttf",
    "18915129d16f211247d9924d83cae087e0a51b8e": "/robots.txt",
    "2517f7189dc3287dae3f151b75bbfb6328a883a3": "/d9a3bda6cacc5a776e8e8007c9de86fb.ttf",
    "7a08df8c79fc1c8f733e53e4f56ebaf883920f1c": "/f4fc68837a518f012ba1df85e7af3acd.ttf",
    "6377fe5788b44c9da6881d17f81568b95ce96578": "/5b54162723d1126c98fb68564c60b860.svg",
    "e2bfcd56016c3c915221ef1c5fc1a17b0776eb91": "/c1034239929f4651cc17d09ed3a28c69.ttf",
    "86fb6a305456deb4ba73278b867f6fb26756f1ed": "/875fbeca9494f6630328545f2708e14b.svg",
    "e917d0dcb7b5ca38a06d482849acb810986240f2": "/f2b064ffc4aa426ea2e2b81bd4662a63.ttf",
    "855222ea35f77d81a9b6102bf2f254aeadbb8838": "/17be7aaf2526759a42c66da7683e37d4.svg",
    "be4ef2aac7775a4b0179c0ecfce6cea8f7783f63": "/e9c5c588e39d0765d30bcd6594734102.ttf",
    "049e453225a4be3e7499771bfd138295c90fe2f0": "/76cfeae5ba55025f20b1a633a2aa1810.svg",
    "4409d5e328438b5586be46066e457a12c04654c7": "/77bf2dc2ec18ab13756cbe6aac3e9a45.svg",
    "21203fefc13dc76616319eccda28643bfd91d6df": "/6d2534827a098a8753837bdad6dd180a.svg",
    "e76be894b09311ae195b57041814fbaa964b66a9": "/43c043bccc84e7e05e2442516ccdd4ff.jpg",
    "85d8b3d726f8eb89fafb0060561b104b6e9acf21": "/d75199d9299ec99171310c60026a9476.ttf",
    "5ef5b38acf21ea7d4d60087e49f081f40bf0a68f": "/favicon.ico",
    "e5c03fd4d0715d3a59db5fdba4a19374cf3cc9de": "/be57951d47bc6b1635653a38cbdf30fd.woff2",
    "94d3ee3acdbd00e37a715a25f2b5237666b5b8a3": "/8afe4dc13b83b66fec0ea671419954cc.ttf",
    "08936fac810b5b3349366ca8f8de0eec5307cd87": "/a840e539f4f9f5b8ceb038072848ae2f.ttf",
    "645e04c53c6b5b35bce654a811ebce16af8aa721": "/14d00dab1f6802e787183ecab5cce85e.ttf",
    "6fa0418f91032680d2d8fe4843009f2c80faa61d": "/a9bed017984a258097841902b696a7a6.ttf",
    "41c0cf29e96590fcbed63b7725bff10e9a110ef4": "/38ff1cb52fae6003a50159bc910b9782.ttf",
    "e9ffdf6bed54d38dd478c20743b250d425025dcf": "/fb05c6adb409f27ffe4f9ac4b2a0d323.svg",
    "0c8bed0a5942b2388d36b11c115685d9f01700b0": "/9841f3d906521f7479a5ba70612aa8c8.ttf",
    "875cf0cecd647bcf22e79d633d868c1b1ec98dfa": "/08c20a487911694291bd8c5de41315ad.ttf",
    "6de8952ca08d27ee77f57347d2cef4b4e26aa78f": "/19406f767addf00d2ea82cdc9ab104ce.ttf",
    "af9509e43f7a2a9a874bb118877daf1c56a5cb6c": "/fc6854e59e19fbcf27ce8e064054a3ed.svg",
    "f76102b361e705751a83b7b22fe954daf1f27dd4": "/0613c488cf7911af70db821bdd05dfc4.ttf",
    "fdd3002e7d814ee47c1c1b8487c72c6bbb3a2d00": "/093ee89be9ede30383f39a899c485a82.ttf",
    "41ea8bf640e3f1b497d8ff1faf79b39d55f9fd84": "/11598c28bd4c62d359b58d8a810f385f.ttf",
    "7ef9ab294def7aa1bfff2176b6cbf9f37e9b1c8a": "/68c5662ec609e6763f13acc6594809aa.svg",
    "3e33ed7b0180507e7384f2644c6ff46b7bafd244": "/33bea45d54f9bf1e62b5e9d6b05b6bfe.svg",
    "8ebecbac39bbcd437ed14785ba8e9efb53cfda17": "/890d9910230752c6a88d8b5d5c3a1895.ttf",
    "a1daba027dfec957d55f40a4ce9d662b6914fd91": "/699335202b9480f4f7916a8df4fb8f41.jpg",
    "ad1d57208646fef510b22a7f47c410501e8413a9": "/sitemap.xml",
    "2bee15b4614d43529aefb416b5c1b084b92c7a3c": "/a511edd89a551e8f0db621724e1f93bd.ttf",
    "283f21b44efbdbf276ba802be2d949a36bbc4233": "/bf59c687bc6d3a70204d3944082c5cc0.ttf",
    "ca6f8e9559eb75343692eb66cf8a35e736c6c1e6": "/41520cbd26d45a314080d93e2db791d2.svg",
    "ef041d73d869f38923905aff8c30bf38d1fedbf0": "/npm.react-fast-compare.c498ae394b734ed34d88.chunk.js",
    "dca8269e7995c98e0773efe72b9ce5978497eaa4": "/npm.react-helmet.27cecc42a65694f42916.chunk.js",
    "a516e76a11865e2f04cc47f5ad5e907561e30b69": "/npm.react-side-effect.11d575f686200d838305.chunk.js",
    "99efedadac7a86b340d144e2f7ce49387eabda00": "/npm.shallowequal.bf436f70b1fcfbf4687e.chunk.js",
    "dbb04ae199fcca114660e939032713f2a8499906": "/npm.intl.322ea77011d5e7e0553b.chunk.js",
    "7aaffe054d51a60b53d593a1a6f3cfef30007489": "/main.15c1d803c1116562de6f.chunk.js",
    "03808c991755f7edeaf130b5a38ea533528346b7": "/npm.babel.7a100477f9f986a0d18a.chunk.js",
    "331c9621ba80bfb485560bced5fd1aff647c03dd": "/npm.connected-react-router.368edfa3c59066d77d2a.chunk.js",
    "e60c663f1c4d0b67a7d79a1cf1ba5cc7b569cb76": "/npm.core-js.7d7d0ec1e85102d35a26.chunk.js",
    "278eb29920ab3a0058b43506d6cc61cb5f59d96b": "/npm.emotion.3adea6dd86959a260f2c.chunk.js",
    "2b0ab65f1261b29e6d18fd0b31c9f21ee19fd4b3": "/npm.mui.c89f6c28a53690bf443b.chunk.js",
    "54e2bc2a628e5006fc186f50a1f26c0fad988cec": "/npm.react-app-polyfill.28db4f98c175ee200fb7.chunk.js",
    "4589b735e644a2b4332f9b07ae11d377bc301c45": "/npm.react-redux.4ab2238accaf843cb8bb.chunk.js",
    "81a47075e87d41ab9f5998377cc28b123bbe6ace": "/npm.react-transition-group.d6427442362ce0cf67df.chunk.js",
    "5dcc52137a39fcbf6c5460d4dd7d036793506d56": "/npm.redux-saga.b38f02a2426979adfaea.chunk.js",
    "9b8cfdb52263dd85fd77a5f277c3ea647599ef4a": "/runtime.8ffac6e7aa9b272269dd.js",
    "b8d6b6a5a0d71104f23425854b4600ce43dabc26": "/16.4739e34a03f1322006ef.chunk.js",
    "f24e36d5a985b596645e0c8645e7703913c886dc": "/17.4f19d52c9f866ac9a832.chunk.js",
    "03787adfdca036aa935318cf9677d8fef28d40ea": "/18.b8edfdcc92a9abf8b4fc.chunk.js",
    "b72439d935e74af263b2a7591633d326d3efddac": "/19.eec1c0d54ee66cfb38a9.chunk.js",
    "5b6093c8f2d92558774a3e0930addf2e2ed6f469": "/20.147e4edb3838dafe268a.chunk.js",
    "37118c9d495304ea9aea952736ec99c1151219c2": "/21.fb7355dd7478bea7a90b.chunk.js",
    "b4b2622b5a3ce5d0b1440b16b7726061bd1fbf7d": "/22.a0a8ba3cddc024b962be.chunk.js",
    "19516d8424441af42a17cd94a546d8a1112575f9": "/23.911ce7216db1baabd93f.chunk.js",
    "afda4440c97dc3212b11c0ea2feeb8148e2258e8": "/24.f2ad56a9af7537e067c9.chunk.js",
    "cf69216fe563ad7bda606633e69413593e282262": "/25.b7db9d036b4cd0fb7cfc.chunk.js",
    "24c4961fb2d9773d76c653b2b232459cf041f9de": "/26.d5bb2b95a847f525bda2.chunk.js",
    "7fe4c15a657d005bc2c1181b8041cbb68de4fb82": "/27.638e35060be8481e33e3.chunk.js",
    "6ec1e99983175dd63ed46f4389061820dba8bfbc": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "9/13/2022, 12:03:35 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });